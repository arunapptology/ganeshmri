

//   $("a").mouseover(function(){

//    var img =  $("a").attr("href");

//    alert(img)

//   });



