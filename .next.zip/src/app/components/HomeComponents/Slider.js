
import React, { useEffect, useState } from 'react'

 
const Slider = () => {

	const [ banner , setBanner] = useState(0);

    return (
      <>
        
      
      
      </>
    )


  
}

export default Slider