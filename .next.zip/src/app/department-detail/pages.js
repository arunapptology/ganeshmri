import React from 'react'

const pages = () => {
  return (
    <div>pages</div>
  )
}

export default pages