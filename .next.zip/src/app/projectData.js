[
    {
        "title": "thing0",
        "fname": "thing0",
        "desc": "hi there this the description",
        "img": "here image path",
        "github": "here github url",
        "link": "here other link if available"
    },
    {
        "title": "thing1",
        "fname": "thing1",
        "desc": "hi there this the description",
        "img": "here image path",
        "github": "here github url",
        "link": "here other link if available"
    },
    {
        "title": "thing2",
        "fname": "thing2",
        "desc": "hi there this the description",
        "img": "here image path",
        "github": "here github url",
        "link": "here other link if available"
    }
]